#!/usr/bin/env python
# coding: utf-8

# In[7]:


# Intialization
import os
import sys

os.environ["SPARK_HOME"] = "/home/talentum/spark"
os.environ["PYLIB"] = os.environ["SPARK_HOME"] + "/python/lib"
# In below two lines, use /usr/bin/python2.7 if you want to use Python 2
os.environ["PYSPARK_PYTHON"] = "/usr/bin/python3.6" 
os.environ["PYSPARK_DRIVER_PYTHON"] = "/usr/bin/python3"
sys.path.insert(0, os.environ["PYLIB"] +"/py4j-0.10.7-src.zip")
sys.path.insert(0, os.environ["PYLIB"] +"/pyspark.zip")

# NOTE: Whichever package you want mention here.
# os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages com.databricks:spark-xml_2.11:0.6.0 pyspark-shell' 
# os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages org.apache.spark:spark-avro_2.11:2.4.0 pyspark-shell'
os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages com.databricks:spark-xml_2.11:0.6.0,org.apache.spark:spark-avro_2.11:2.4.3 pyspark-shell'
# os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages com.databricks:spark-xml_2.11:0.6.0,org.apache.spark:spark-avro_2.11:2.4.0 pyspark-shell'


# In[8]:


#Entrypoint 2.x
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().getOrCreate()

# On yarn:
# spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().master("yarn").getOrCreate()
# specify .master("yarn")

sc = spark.sparkContext


# Q1. A

# In[9]:


file_path = "file:///home/talentum/spark-titanic/titanic.csv"

# Load the tips.csv dataset
df = spark.read.csv(file_path, header=True, inferSchema=True)

# Display schema
print("Schema of Titanic DataFrame:")
df.printSchema()

# Display first 10 records
print("First 10 records:")
df.show(10)


# Q1. B

# In[10]:


from pyspark.sql.functions import col, when

# 1. Remove rows having null values in the 'age' column
df_cleaned = tips_df.filter(col("age").isNotNull())

# 2. Create the 'Age_Group' column with the specified logic
df_with_age_group = df_cleaned.withColumn("Age_Group", 
    when(col("age") < 18, "child")
    .when((col("age") >= 18) & (col("age") <= 59), "adult")
    .otherwise("Senior")
)

# 3. Display the resulting DataFrame
df_with_age_group.show()


# In[ ]:





# In[ ]:





# Q1. C

# In[13]:


# Register DataFrame as a temporary SQL table/view
from pyspark.sql.functions import col, round as _round
df.createOrReplaceTempView("titanic")


# In[14]:


# 3. Find the number of passengers in each passenger class using Spark SQL
result = spark.sql("""
    SELECT pclass, COUNT(*) as passenger_count
    FROM titanic
    GROUP BY pclass
    ORDER BY pclass
""")

result.show()


# In[15]:


# Calculate average age per passenger class
avg_age_query = spark.sql("""
    SELECT pclass, AVG(age) as average_age
    FROM titanic
    GROUP BY pclass
    ORDER BY pclass
""")

# Display the results
avg_age_query.show()


# In[16]:


# Query to retrieve the top 5 oldest passengers
oldest_passengers = spark.sql("""
    SELECT *
    FROM titanic
    ORDER BY age DESC
    LIMIT 5
""")

# Display the results
oldest_passengers.show()


# Q1.D

# In[17]:


# Define the output path
output_path = "file:///home/talentum/spark-titanic/transformed_data"

# Save the DataFrame as a CSV file
# header=True ensures the column names are included in the output
df_with_age_group.write.mode("overwrite").csv(output_path, header=True)

print(f"DataFrame saved successfully to: {output_path}")


# In[ ]:




